# maxilofacial-ai
Integración de técnicas de imagen y reconstrucción 3D con inteligencia artificial para la predicción y perfeccionamiento de resultados en cirugía maxilofacial.
